package com.adit.sirs.core.error

sealed class AppError : Exception() {
    data class AuthError(override val message: String) : AppError()
    data class NetworkError(override val message: String) : AppError()
    data class FirestoreError(override val message: String) : AppError()
    data class ValidationError(override val message: String) : AppError()
    data class UploadError(override val message: String) : AppError()
    data class PermissionError(override val message: String) : AppError()
    data class UnknownError(override val message: String = "An unexpected error occurred") : AppError()
}

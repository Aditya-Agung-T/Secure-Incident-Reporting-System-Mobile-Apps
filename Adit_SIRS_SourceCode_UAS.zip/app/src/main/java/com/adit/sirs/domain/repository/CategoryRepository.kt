package com.adit.sirs.domain.repository

import com.adit.sirs.core.common.Result
import com.adit.sirs.domain.model.Category
import kotlinx.coroutines.flow.Flow

interface CategoryRepository {
    fun observeActiveCategories(): Flow<List<Category>>
    fun observeAllCategories(): Flow<List<Category>>
    suspend fun createCategory(name: String, slug: String, description: String?, mitigationTips: List<String>, recommendedEvidence: List<String>, createdBy: String): Result<String>
    suspend fun updateCategory(categoryId: String, name: String, slug: String, description: String?, mitigationTips: List<String>, recommendedEvidence: List<String>): Result<Unit>
    suspend fun toggleCategoryActive(categoryId: String, isActive: Boolean): Result<Unit>
    suspend fun deleteCategory(categoryId: String): Result<Unit>
}

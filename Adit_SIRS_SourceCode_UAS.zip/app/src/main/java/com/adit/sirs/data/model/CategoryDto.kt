package com.adit.sirs.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

data class CategoryDto(
    val id: String = "",
    val name: String = "",
    val slug: String = "",
    val description: String? = null,
    val mitigationTips: List<String> = emptyList(),
    val recommendedEvidence: List<String> = emptyList(),
    @get:PropertyName("isActive") @set:PropertyName("isActive") var isActive: Boolean = true,
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
    val deletedAt: Timestamp? = null
)

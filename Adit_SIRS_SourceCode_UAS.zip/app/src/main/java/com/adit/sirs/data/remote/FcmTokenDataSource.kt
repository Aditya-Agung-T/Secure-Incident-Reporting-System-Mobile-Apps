package com.adit.sirs.data.remote

import android.os.Build
import com.adit.sirs.core.constants.AppConstants
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FcmTokenDataSource @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val messaging: FirebaseMessaging
) {
    suspend fun registerToken(uid: String, role: String) {
        val token = messaging.token.await()
        val data = mapOf(
            "uid" to uid,
            "token" to token,
            "platform" to "android",
            "deviceName" to "${Build.MANUFACTURER} ${Build.MODEL}",
            "role" to role,
            "isActive" to true,
            "createdAt" to Timestamp.now(),
            "updatedAt" to Timestamp.now()
        )
        firestore.collection(AppConstants.COLLECTION_DEVICE_TOKENS)
            .document(token)
            .set(data)
            .await()
    }

    suspend fun removeToken() {
        try {
            val token = messaging.token.await()
            firestore.collection(AppConstants.COLLECTION_DEVICE_TOKENS)
                .document(token)
                .delete()
                .await()
        } catch (_: Exception) {
            // Ignore token removal errors during logout
        }
    }
}

package com.adit.sirs.ui.theme

// Typography moved to com.adit.sirs.presentation.theme.SirsTypography

package com.adit.sirs.domain.model

import com.google.firebase.Timestamp

data class ActivityLog(
    val id: String = "",
    val actorId: String? = null,
    val actorName: String? = null,
    val actorRole: String? = null,
    val action: String = "",
    val entityType: String? = null,
    val entityId: String? = null,
    val description: String = "",
    val context: Map<String, Any>? = null,
    val createdAt: Timestamp? = null
)

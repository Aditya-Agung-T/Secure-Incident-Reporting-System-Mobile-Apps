package com.adit.sirs.ui.theme

// Re-exported from presentation theme

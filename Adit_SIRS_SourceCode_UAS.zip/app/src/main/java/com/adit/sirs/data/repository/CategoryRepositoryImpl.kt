package com.adit.sirs.data.repository

import com.adit.sirs.core.common.Result
import com.adit.sirs.core.error.ErrorMapper
import com.adit.sirs.data.mapper.CategoryMapper
import com.adit.sirs.data.remote.FirestoreCategoryDataSource
import com.adit.sirs.domain.model.Category
import com.adit.sirs.domain.repository.CategoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CategoryRepositoryImpl @Inject constructor(
    private val categoryDataSource: FirestoreCategoryDataSource
) : CategoryRepository {

    override fun observeActiveCategories(): Flow<List<Category>> {
        return categoryDataSource.observeActiveCategories().map { dtos ->
            dtos.map { CategoryMapper.toDomain(it) }
        }
    }

    override fun observeAllCategories(): Flow<List<Category>> {
        return categoryDataSource.observeAllCategories().map { dtos ->
            dtos.map { CategoryMapper.toDomain(it) }
        }
    }

    override suspend fun createCategory(name: String, slug: String, description: String?, mitigationTips: List<String>, recommendedEvidence: List<String>, createdBy: String): Result<String> {
        return try {
            val id = categoryDataSource.createCategory(name, slug, description, mitigationTips, recommendedEvidence, createdBy)
            Result.Success(id)
        } catch (e: Exception) {
            Result.Error(e, ErrorMapper.toUserMessage(e))
        }
    }

    override suspend fun updateCategory(categoryId: String, name: String, slug: String, description: String?, mitigationTips: List<String>, recommendedEvidence: List<String>): Result<Unit> {
        return try {
            categoryDataSource.updateCategory(categoryId, name, slug, description, mitigationTips, recommendedEvidence)
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, ErrorMapper.toUserMessage(e))
        }
    }

    override suspend fun toggleCategoryActive(categoryId: String, isActive: Boolean): Result<Unit> {
        return try {
            categoryDataSource.toggleCategoryActive(categoryId, isActive)
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, ErrorMapper.toUserMessage(e))
        }
    }

    override suspend fun deleteCategory(categoryId: String): Result<Unit> {
        return try {
            categoryDataSource.deleteCategory(categoryId)
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, ErrorMapper.toUserMessage(e))
        }
    }
}

package com.adit.sirs.domain.model

import com.google.firebase.Timestamp

data class StatusHistory(
    val id: String = "",
    val fromStatus: String? = null,
    val toStatus: String = "",
    val note: String? = null,
    val changedBy: String = "",
    val changedByName: String = "",
    val createdAt: Timestamp? = null
)

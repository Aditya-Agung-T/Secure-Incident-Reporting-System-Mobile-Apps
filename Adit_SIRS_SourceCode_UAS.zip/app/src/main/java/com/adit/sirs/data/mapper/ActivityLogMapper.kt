package com.adit.sirs.data.mapper

import com.adit.sirs.data.model.ActivityLogDto
import com.adit.sirs.domain.model.ActivityLog

object ActivityLogMapper {
    fun toDomain(dto: ActivityLogDto): ActivityLog {
        return ActivityLog(
            id = dto.id,
            actorId = dto.actorId,
            actorName = dto.actorName,
            actorRole = dto.actorRole,
            action = dto.action,
            entityType = dto.entityType,
            entityId = dto.entityId,
            description = dto.description,
            context = dto.context,
            createdAt = dto.createdAt
        )
    }
}

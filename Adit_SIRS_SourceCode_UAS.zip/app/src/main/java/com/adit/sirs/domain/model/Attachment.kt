package com.adit.sirs.domain.model

import com.google.firebase.Timestamp

data class Attachment(
    val originalName: String = "",
    val publicId: String = "",
    val secureUrl: String = "",
    val resourceType: String = "",
    val format: String = "",
    val mimeType: String = "",
    val bytes: Long = 0,
    val uploadedAt: Timestamp? = null
)

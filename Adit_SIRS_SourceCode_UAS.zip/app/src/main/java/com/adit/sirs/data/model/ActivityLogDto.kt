package com.adit.sirs.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.ServerTimestamp

data class ActivityLogDto(
    val id: String = "",
    val actorId: String? = null,
    val actorName: String? = null,
    val actorRole: String? = null,
    val action: String = "",
    val entityType: String? = null,
    val entityId: String? = null,
    val description: String = "",
    val context: Map<String, Any>? = null,
    @ServerTimestamp val createdAt: Timestamp? = null
)

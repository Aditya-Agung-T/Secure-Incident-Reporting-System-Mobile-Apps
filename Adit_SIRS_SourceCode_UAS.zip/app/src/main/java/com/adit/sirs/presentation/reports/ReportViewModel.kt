package com.adit.sirs.presentation.reports

import android.content.ContentResolver
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adit.sirs.core.common.Result
import com.adit.sirs.core.common.UiState
import com.adit.sirs.core.security.FileValidation
import com.adit.sirs.core.security.SlaCalculator
import com.adit.sirs.data.mapper.ReportMapper
import com.adit.sirs.domain.model.*
import com.adit.sirs.domain.repository.AdminRepository
import com.adit.sirs.domain.repository.AuthRepository
import com.adit.sirs.domain.repository.CategoryRepository
import com.adit.sirs.domain.repository.ReportRepository
import com.google.firebase.Timestamp
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Date
import javax.inject.Inject

import com.adit.sirs.core.firebase.AnalyticsHelper
import com.adit.sirs.core.common.RateLimiter

@HiltViewModel
class ReportViewModel @Inject constructor(
    private val reportRepository: ReportRepository,
    private val categoryRepository: CategoryRepository,
    private val authRepository: AuthRepository,
    private val adminRepository: AdminRepository,
    private val analyticsHelper: AnalyticsHelper,
    private val rateLimiter: RateLimiter
) : ViewModel() {

    private val _formState = MutableStateFlow(ReportFormState())
    val formState: StateFlow<ReportFormState> = _formState.asStateFlow()

    private val _categories = MutableStateFlow<List<Category>>(emptyList())
    val categories: StateFlow<List<Category>> = _categories.asStateFlow()

    private val _userReports = MutableStateFlow<UiState<List<IncidentReport>>>(UiState.Loading)
    val userReports: StateFlow<UiState<List<IncidentReport>>> = _userReports.asStateFlow()

    private val _reportDetail = MutableStateFlow<UiState<IncidentReport>>(UiState.Loading)
    val reportDetail: StateFlow<UiState<IncidentReport>> = _reportDetail.asStateFlow()

    private val _statusHistories = MutableStateFlow<List<StatusHistory>>(emptyList())
    val statusHistories: StateFlow<List<StatusHistory>> = _statusHistories.asStateFlow()

    private val _submitState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val submitState: StateFlow<UiState<String>> = _submitState.asStateFlow()

    private val _uploadProgress = MutableStateFlow(false)
    val uploadProgress: StateFlow<Boolean> = _uploadProgress.asStateFlow()

    private val _statusFilter = MutableStateFlow<String?>(null)
    val statusFilter: StateFlow<String?> = _statusFilter.asStateFlow()

    private val _severityFilter = MutableStateFlow<String?>(null)
    val severityFilter: StateFlow<String?> = _severityFilter.asStateFlow()

    private var allLoadedReports: List<IncidentReport> = emptyList()

    private var currentUser: User? = null

    init {
        loadCategories()
        loadCurrentUser()
    }

    private fun loadCurrentUser() {
        viewModelScope.launch {
            when (val result = authRepository.getCurrentUser()) {
                is Result.Success -> {
                    currentUser = result.data
                    // Auto-load reports when user is ready
                    loadUserReports()
                }
                else -> {}
            }
        }
    }

    private fun loadCategories() {
        viewModelScope.launch {
            categoryRepository.observeActiveCategories()
                .catch { _categories.value = emptyList() }
                .collect { _categories.value = it }
        }
    }

    fun loadUserReports(statusFilter: String? = null) {
        val uid = currentUser?.uid ?: return
        viewModelScope.launch {
            reportRepository.observeUserReports(uid, statusFilter)
                .catch { _userReports.value = UiState.Error(it.message ?: "Failed to load reports") }
                .collect {
                    allLoadedReports = it
                    applyReportFilters()
                }
        }
    }

    fun setStatusFilter(status: String?) {
        _statusFilter.value = status
        loadUserReports(status)
    }

    fun setSeverityFilter(severity: String?) {
        _severityFilter.value = severity
        applyReportFilters()
    }

    private fun applyReportFilters() {
        val severity = _severityFilter.value
        val filtered = if (severity == null) {
            allLoadedReports
        } else {
            allLoadedReports.filter { it.severity.value == severity }
        }
        _userReports.value = UiState.Success(filtered)
    }

    fun loadReportDetail(reportId: String) {
        analyticsHelper.logReportStatusViewed("detail")
        viewModelScope.launch {
            reportRepository.observeReport(reportId)
                .catch { _reportDetail.value = UiState.Error(it.message ?: "Failed to load report") }
                .collect { report ->
                    if (report != null) {
                        _reportDetail.value = UiState.Success(report)
                    } else {
                        _reportDetail.value = UiState.Error("Report not found")
                    }
                }
        }
        viewModelScope.launch {
            reportRepository.observeStatusHistories(reportId)
                .catch { _statusHistories.value = emptyList() }
                .collect { _statusHistories.value = it }
        }
    }

    fun updateFormField(update: ReportFormState.() -> ReportFormState) {
        _formState.value = _formState.value.update()
    }

    fun setAttachment(
        contentResolver: ContentResolver,
        uri: Uri
    ) {
        val result = FileValidation.validateFile(contentResolver, uri)
        if (result.isValid) {
            _formState.value = _formState.value.copy(
                attachmentUri = uri,
                attachmentName = result.fileName,
                attachmentMimeType = result.mimeType,
                attachmentSize = result.fileSize
            )
        } else {
            _submitState.value = UiState.Error(result.errorMessage ?: "Invalid file")
        }
    }

    fun clearAttachment() {
        _formState.value = _formState.value.copy(
            attachmentUri = null,
            attachmentName = null,
            attachmentMimeType = null,
            attachmentSize = 0
        )
    }

    private var lastSuccessfulUpload: Attachment? = null

    fun submitReport(contentResolver: ContentResolver) {
        val form = _formState.value
        if (!form.isValid) {
            _submitState.value = UiState.Error("Lengkapi semua field wajib")
            return
        }

        val user = currentUser ?: run {
            _submitState.value = UiState.Error("User tidak terautentikasi")
            return
        }

        viewModelScope.launch {
            _submitState.value = UiState.Loading

            // Rate limit check for report creation
            val rateCheck = rateLimiter.canCreateReport(user.uid)
            if (!rateCheck.allowed) {
                _submitState.value = UiState.Error(rateCheck.message ?: "Terlalu banyak permintaan")
                return@launch
            }

            // Upload attachment if present
            var attachment: Attachment? = null
            if (form.attachmentUri != null && form.attachmentMimeType != null && form.attachmentName != null) {
                val uploadRateCheck = rateLimiter.canUploadFile(user.uid)
                if (!uploadRateCheck.allowed) {
                    _submitState.value = UiState.Error(uploadRateCheck.message ?: "Mohon tunggu sebelum upload lagi")
                    return@launch
                }
                _uploadProgress.value = true
                analyticsHelper.logUploadStarted(form.attachmentMimeType, form.attachmentSize)
                when (val uploadResult = reportRepository.uploadAttachment(
                    contentResolver, form.attachmentUri, form.attachmentMimeType, form.attachmentName
                )) {
                    is Result.Success -> {
                        attachment = uploadResult.data
                        lastSuccessfulUpload = uploadResult.data
                        analyticsHelper.logUploadSuccess(form.attachmentMimeType, form.attachmentSize)
                    }
                    is Result.Error -> {
                        _uploadProgress.value = false
                        analyticsHelper.logUploadFailed(form.attachmentMimeType, form.attachmentSize, uploadResult.message ?: "Unknown")
                        _submitState.value = UiState.Error(uploadResult.message ?: "Upload failed")
                        return@launch
                    }
                    is Result.Loading -> {}
                }
                _uploadProgress.value = false
                rateLimiter.recordUpload(user.uid)
            }

            val submittedAt = Timestamp.now()
            val severity = Severity.fromString(form.severity)
            val reportData = mutableMapOf<String, Any?>(
                "slaDeadlineAt" to SlaCalculator.deadlineFrom(submittedAt, severity),
                "userId" to user.uid,
                "userName" to user.name,
                "userEmail" to user.email,
                "categoryId" to form.categoryId,
                "categoryName" to form.categoryName,
                "title" to form.title,
                "description" to form.description,
                "location" to form.location,
                "incidentDate" to Timestamp(Date(form.incidentDate!!)),
                "severity" to form.severity,
                "status" to "pending"
            )

            if (attachment != null) {
                reportData["attachment"] = ReportMapper.attachmentToMap(attachment)
            }

            when (val result = reportRepository.createReport(reportData)) {
                is Result.Success -> {
                    lastSuccessfulUpload = null // clear cache on success
                    try {
                        adminRepository.logActivity(
                            actorId = user.uid,
                            actorName = user.name,
                            actorRole = user.role.value,
                            action = "report.created",
                            entityType = "incidentReport",
                            entityId = result.data,
                            description = "Report created: ${form.title}"
                        )
                        if (attachment != null) {
                            adminRepository.logActivity(
                                actorId = user.uid,
                                actorName = user.name,
                                actorRole = user.role.value,
                                action = "attachment.uploaded",
                                entityType = "incidentReport",
                                entityId = result.data,
                                description = "Attachment uploaded: ${attachment.originalName}"
                            )
                        }
                    } catch (_: Exception) { }

                    rateLimiter.recordReport(user.uid)
                    analyticsHelper.logReportCreated(form.severity, attachment != null)
                    _submitState.value = UiState.Success(result.data)
                    _formState.value = ReportFormState()
                }
                is Result.Error -> {
                    // If upload succeeded but Firestore failed, offer retry
                    if (attachment != null) {
                        _submitState.value = UiState.Error(
                            "Laporan gagal disimpan. File sudah terupload. Tap Submit lagi untuk mencoba ulang."
                        )
                    } else {
                        _submitState.value = UiState.Error(result.message ?: "Gagal membuat laporan")
                    }
                }
                is Result.Loading -> {}
            }
        }
    }

    fun updateReport(reportId: String, contentResolver: ContentResolver) {
        val form = _formState.value
        if (!form.isValid) {
            _submitState.value = UiState.Error("Lengkapi semua field wajib")
            return
        }

        val user = currentUser ?: run {
            _submitState.value = UiState.Error("User tidak terautentikasi")
            return
        }

        viewModelScope.launch {
            _submitState.value = UiState.Loading

            var attachment: Attachment? = null
            if (form.attachmentUri != null && form.attachmentMimeType != null && form.attachmentName != null) {
                _uploadProgress.value = true
                analyticsHelper.logUploadStarted(form.attachmentMimeType, form.attachmentSize)
                when (val uploadResult = reportRepository.uploadAttachment(
                    contentResolver, form.attachmentUri, form.attachmentMimeType, form.attachmentName
                )) {
                    is Result.Success -> {
                        attachment = uploadResult.data
                        analyticsHelper.logUploadSuccess(form.attachmentMimeType, form.attachmentSize)
                    }
                    is Result.Error -> {
                        _uploadProgress.value = false
                        _submitState.value = UiState.Error(uploadResult.message ?: "Upload failed")
                        return@launch
                    }
                    is Result.Loading -> {}
                }
                _uploadProgress.value = false
            }

            val updateData = mutableMapOf<String, Any?>(
                "categoryId" to form.categoryId,
                "categoryName" to form.categoryName,
                "title" to form.title,
                "description" to form.description,
                "location" to form.location,
                "incidentDate" to Timestamp(Date(form.incidentDate!!)),
                "severity" to form.severity
            )

            if (attachment != null) {
                updateData["attachment"] = ReportMapper.attachmentToMap(attachment)
            }

            when (val result = reportRepository.updateReport(reportId, updateData)) {
                is Result.Success -> {
                    try {
                        adminRepository.logActivity(
                            actorId = user.uid,
                            actorName = user.name,
                            actorRole = user.role.value,
                            action = "report.updated",
                            entityType = "incidentReport",
                            entityId = reportId,
                            description = "Report updated: ${form.title}"
                        )
                    } catch (_: Exception) { }

                    _submitState.value = UiState.Success(reportId)
                }
                is Result.Error -> {
                    _submitState.value = UiState.Error(result.message ?: "Failed to update report")
                }
                is Result.Loading -> {}
            }
        }
    }

    fun deleteReport(reportId: String) {
        viewModelScope.launch {
            _submitState.value = UiState.Loading
            when (val result = reportRepository.deleteReport(reportId)) {
                is Result.Success -> {
                    try {
                        val user = currentUser
                        if (user != null) {
                            adminRepository.logActivity(
                                actorId = user.uid,
                                actorName = user.name,
                                actorRole = user.role.value,
                                action = "report.deleted",
                                entityType = "incidentReport",
                                entityId = reportId,
                                description = "Report deleted"
                            )
                        }
                    } catch (_: Exception) { }
                    _submitState.value = UiState.Success("deleted")
                }
                is Result.Error -> {
                    _submitState.value = UiState.Error(result.message ?: "Failed to delete report")
                }
                is Result.Loading -> {}
            }
        }
    }

    fun prefillForm(report: IncidentReport) {
        _formState.value = ReportFormState(
            title = report.title,
            categoryId = report.categoryId,
            categoryName = report.categoryName,
            description = report.description,
            location = report.location,
            incidentDate = report.incidentDate?.toDate()?.time,
            severity = report.severity.value
        )
    }

    fun resetSubmitState() {
        _submitState.value = UiState.Idle
    }
}

package com.adit.sirs.ui.theme

// Theme moved to com.adit.sirs.presentation.theme.SIRSTheme

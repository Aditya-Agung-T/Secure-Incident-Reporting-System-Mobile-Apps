package com.adit.sirs.data.remote

import android.content.ContentResolver
import android.net.Uri
import com.adit.sirs.BuildConfig
import com.adit.sirs.domain.model.Attachment
import com.google.firebase.Timestamp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CloudinaryUploadDataSource @Inject constructor() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .writeTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    suspend fun uploadFile(
        contentResolver: ContentResolver,
        fileUri: Uri,
        mimeType: String,
        fileName: String
    ): Attachment = withContext(Dispatchers.IO) {
        val cloudName = BuildConfig.CLOUDINARY_CLOUD_NAME
        val uploadPreset = BuildConfig.CLOUDINARY_UPLOAD_PRESET
        val folder = BuildConfig.CLOUDINARY_UPLOAD_FOLDER

        val resourceType = if (mimeType == "application/pdf") "raw" else "image"
        val uploadUrl = "https://api.cloudinary.com/v1_1/$cloudName/$resourceType/upload"

        val inputStream = contentResolver.openInputStream(fileUri)
            ?: throw IOException("Cannot open file")

        val fileBytes = inputStream.use { it.readBytes() }
        val mediaType = mimeType.toMediaType()

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", fileName, fileBytes.toRequestBody(mediaType))
            .addFormDataPart("upload_preset", uploadPreset)
            .addFormDataPart("folder", folder)
            .build()

        val request = Request.Builder()
            .url(uploadUrl)
            .post(requestBody)
            .build()

        val response = client.newCall(request).execute()

        if (!response.isSuccessful) {
            val errorBody = response.body?.string() ?: "Unknown error"
            throw IOException("Upload failed: $errorBody")
        }

        val responseBody = response.body?.string()
            ?: throw IOException("Empty response from Cloudinary")

        val json = JSONObject(responseBody)

        Attachment(
            originalName = fileName,
            publicId = json.optString("public_id", ""),
            secureUrl = json.optString("secure_url", ""),
            resourceType = json.optString("resource_type", resourceType),
            format = json.optString("format", ""),
            mimeType = mimeType,
            bytes = json.optLong("bytes", 0),
            uploadedAt = Timestamp.now()
        )
    }

    suspend fun deleteFile(publicId: String, resourceType: String) = withContext(Dispatchers.IO) {
        if (publicId.isBlank()) return@withContext

        val endpoint = BuildConfig.CLOUDINARY_DELETE_ENDPOINT
        if (endpoint.isBlank()) {
            throw IOException("Konfigurasi hapus file Cloudinary belum tersedia. Set CLOUDINARY_DELETE_ENDPOINT ke endpoint backend yang menghapus asset Cloudinary secara aman.")
        }

        val deleteSecret = BuildConfig.CLOUDINARY_DELETE_SECRET
        if (deleteSecret.isBlank()) {
            throw IOException("Konfigurasi secret hapus Cloudinary belum tersedia. Set CLOUDINARY_DELETE_SECRET sesuai secret Cloudflare Worker.")
        }

        val payload = JSONObject()
            .put("publicId", publicId)
            .put("resourceType", resourceType.ifBlank { "image" })
            .put("secret", deleteSecret)
            .toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url(endpoint)
            .post(payload)
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            val errorBody = response.body?.string() ?: "Unknown error"
            throw IOException("Gagal menghapus file Cloudinary: $errorBody")
        }
    }
}

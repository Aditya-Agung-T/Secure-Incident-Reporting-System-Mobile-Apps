package com.adit.sirs.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.ServerTimestamp

data class StatusHistoryDto(
    val id: String = "",
    val fromStatus: String? = null,
    val toStatus: String = "",
    val note: String? = null,
    val changedBy: String = "",
    val changedByName: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

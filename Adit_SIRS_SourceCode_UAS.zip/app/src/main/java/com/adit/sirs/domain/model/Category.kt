package com.adit.sirs.domain.model

import com.google.firebase.Timestamp

data class Category(
    val id: String = "",
    val name: String = "",
    val slug: String = "",
    val description: String? = null,
    val mitigationTips: List<String> = emptyList(),
    val recommendedEvidence: List<String> = emptyList(),
    val isActive: Boolean = true,
    val createdBy: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null,
    val deletedAt: Timestamp? = null
)

package com.adit.sirs.domain.model

enum class IncidentStatus(val value: String, val displayName: String) {
    PENDING("pending", "Pending"),
    INVESTIGATING("investigating", "Investigating"),
    RESOLVED("resolved", "Resolved"),
    REJECTED("rejected", "Rejected");

    companion object {
        fun fromString(value: String): IncidentStatus {
            return entries.firstOrNull { it.value == value } ?: PENDING
        }
    }
}

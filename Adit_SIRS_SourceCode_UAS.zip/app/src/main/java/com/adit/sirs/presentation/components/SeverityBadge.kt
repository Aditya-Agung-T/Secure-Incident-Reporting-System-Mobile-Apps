package com.adit.sirs.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.adit.sirs.domain.model.Severity
import com.adit.sirs.presentation.theme.*

@Composable
fun SeverityBadge(severity: Severity, modifier: Modifier = Modifier) {
    val (bgColor, textColor) = when (severity) {
        Severity.LOW -> SeverityLow.copy(alpha = 0.15f) to SeverityLow
        Severity.MEDIUM -> SeverityMedium.copy(alpha = 0.15f) to SeverityMedium
        Severity.HIGH -> SeverityHigh.copy(alpha = 0.15f) to SeverityHigh
        Severity.CRITICAL -> SeverityCritical.copy(alpha = 0.15f) to SeverityCritical
    }

    Text(
        text = severity.displayName,
        style = MaterialTheme.typography.labelSmall,
        color = textColor,
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

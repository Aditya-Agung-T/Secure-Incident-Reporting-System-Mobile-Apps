package com.adit.sirs.domain.repository

import android.content.ContentResolver
import android.net.Uri
import com.adit.sirs.core.common.Result
import com.adit.sirs.domain.model.Attachment
import com.adit.sirs.domain.model.IncidentReport
import com.adit.sirs.domain.model.StatusHistory
import kotlinx.coroutines.flow.Flow

interface ReportRepository {
    fun observeUserReports(userId: String, status: String? = null): Flow<List<IncidentReport>>
    fun observeReport(reportId: String): Flow<IncidentReport?>
    fun observeStatusHistories(reportId: String): Flow<List<StatusHistory>>
    suspend fun createReport(report: Map<String, Any?>): Result<String>
    suspend fun updateReport(reportId: String, data: Map<String, Any?>): Result<Unit>
    suspend fun deleteReport(reportId: String): Result<Unit>
    suspend fun uploadAttachment(
        contentResolver: ContentResolver,
        uri: Uri,
        mimeType: String,
        fileName: String
    ): Result<Attachment>
    suspend fun getReport(reportId: String): Result<IncidentReport?>
}

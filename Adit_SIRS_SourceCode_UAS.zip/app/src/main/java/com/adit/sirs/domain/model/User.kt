package com.adit.sirs.domain.model

import com.google.firebase.Timestamp

data class User(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val role: UserRole = UserRole.USER,
    val isActive: Boolean = true,
    val photoUrl: String? = null,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null,
    val lastLoginAt: Timestamp? = null
) {
    val isAdmin: Boolean get() = role == UserRole.ADMINISTRATOR
}

package com.adit.sirs.domain.model

enum class UserRole(val value: String) {
    USER("user"),
    ADMINISTRATOR("administrator");

    companion object {
        fun fromString(value: String): UserRole {
            return entries.firstOrNull { it.value == value } ?: USER
        }
    }
}

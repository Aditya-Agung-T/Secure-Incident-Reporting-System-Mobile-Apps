package com.adit.sirs.presentation.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adit.sirs.core.common.Result
import com.adit.sirs.core.common.UiState
import com.adit.sirs.domain.model.ActivityLog
import com.adit.sirs.domain.model.Category
import com.adit.sirs.domain.model.IncidentReport
import com.adit.sirs.domain.model.StatusHistory
import com.adit.sirs.domain.model.User
import com.adit.sirs.domain.repository.AdminRepository
import com.adit.sirs.domain.repository.AuthRepository
import com.adit.sirs.domain.repository.CategoryRepository
import com.adit.sirs.domain.repository.ReportRepository
import com.adit.sirs.core.firebase.AnalyticsHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AdminViewModel @Inject constructor(
    private val adminRepository: AdminRepository,
    private val categoryRepository: CategoryRepository,
    private val reportRepository: ReportRepository,
    private val authRepository: AuthRepository,
    private val analyticsHelper: AnalyticsHelper
) : ViewModel() {

    private val _allReports = MutableStateFlow<UiState<List<IncidentReport>>>(UiState.Loading)
    val allReports: StateFlow<UiState<List<IncidentReport>>> = _allReports.asStateFlow()

    private val _reportDetail = MutableStateFlow<UiState<IncidentReport>>(UiState.Loading)
    val reportDetail: StateFlow<UiState<IncidentReport>> = _reportDetail.asStateFlow()

    private val _statusHistories = MutableStateFlow<List<StatusHistory>>(emptyList())
    val statusHistories: StateFlow<List<StatusHistory>> = _statusHistories.asStateFlow()

    private val _categories = MutableStateFlow<UiState<List<Category>>>(UiState.Loading)
    val categories: StateFlow<UiState<List<Category>>> = _categories.asStateFlow()

    private val _activityLogs = MutableStateFlow<UiState<List<ActivityLog>>>(UiState.Loading)
    val activityLogs: StateFlow<UiState<List<ActivityLog>>> = _activityLogs.asStateFlow()

    private val _updateState = MutableStateFlow<UiState<Unit>>(UiState.Idle)
    val updateState: StateFlow<UiState<Unit>> = _updateState.asStateFlow()

    private val _statusFilter = MutableStateFlow<String?>(null)
    val statusFilter: StateFlow<String?> = _statusFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _severityFilter = MutableStateFlow<String?>(null)
    val severityFilter: StateFlow<String?> = _severityFilter.asStateFlow()

    private val _dateStart = MutableStateFlow<Long?>(null)
    val dateStart: StateFlow<Long?> = _dateStart.asStateFlow()

    private val _dateEnd = MutableStateFlow<Long?>(null)
    val dateEnd: StateFlow<Long?> = _dateEnd.asStateFlow()

    private var allLoadedReports: List<IncidentReport> = emptyList()

    private var currentAdmin: User? = null

    init {
        loadCurrentUser()
    }

    private fun loadCurrentUser() {
        viewModelScope.launch {
            when (val result = authRepository.getCurrentUser()) {
                is Result.Success -> {
                    currentAdmin = result.data
                    loadAllReports()
                }
                else -> {}
            }
        }
    }

    fun loadAllReports(statusFilter: String? = null) {
        viewModelScope.launch {
            adminRepository.observeAllReports(statusFilter)
                .catch { _allReports.value = UiState.Error(it.message ?: "Failed to load reports") }
                .collect { reports ->
                    allLoadedReports = reports
                    applyFilters()
                }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        applyFilters()
    }

    fun setSeverityFilter(severity: String?) {
        _severityFilter.value = severity
        applyFilters()
    }

    fun setDateRange(start: Long?, end: Long?) {
        _dateStart.value = start
        _dateEnd.value = end
        applyFilters()
    }

    fun clearDateRange() {
        _dateStart.value = null
        _dateEnd.value = null
        applyFilters()
    }

    fun setStatusFilter(status: String?) {
        _statusFilter.value = status
        loadAllReports(status)
    }

    private fun applyFilters() {
        val query = _searchQuery.value.lowercase()
        val severity = _severityFilter.value
        val dateStart = _dateStart.value
        val dateEnd = _dateEnd.value
        var filtered = allLoadedReports

        if (query.isNotBlank()) {
            filtered = filtered.filter {
                it.title.lowercase().contains(query) ||
                it.reportCode.lowercase().contains(query) ||
                it.userName.lowercase().contains(query) ||
                it.location.lowercase().contains(query)
            }
        }

        if (severity != null) {
            filtered = filtered.filter { it.severity.value == severity }
        }

        if (dateStart != null) {
            filtered = filtered.filter {
                it.createdAt?.toDate()?.time?.let { ts -> ts >= dateStart } ?: true
            }
        }

        if (dateEnd != null) {
            filtered = filtered.filter {
                it.createdAt?.toDate()?.time?.let { ts -> ts <= dateEnd } ?: true
            }
        }

        _allReports.value = UiState.Success(filtered)
    }

    fun loadReportDetail(reportId: String) {
        analyticsHelper.logReportStatusViewed("detail")
        viewModelScope.launch {
            reportRepository.observeReport(reportId)
                .catch { _reportDetail.value = UiState.Error(it.message ?: "Failed") }
                .collect { report ->
                    if (report != null) {
                        _reportDetail.value = UiState.Success(report)
                    } else {
                        _reportDetail.value = UiState.Error("Report not found")
                    }
                }
        }
        viewModelScope.launch {
            reportRepository.observeStatusHistories(reportId)
                .catch { _statusHistories.value = emptyList() }
                .collect { _statusHistories.value = it }
        }
    }

    fun updateReportStatus(
        reportId: String,
        newStatus: String,
        newSeverity: String,
        adminResponse: String?,
        oldStatus: String,
        oldSeverity: String
    ) {
        val admin = currentAdmin ?: return
        viewModelScope.launch {
            _updateState.value = UiState.Loading
            when (val result = adminRepository.updateReportStatus(
                reportId = reportId,
                newStatus = newStatus,
                newSeverity = newSeverity,
                adminResponse = adminResponse,
                adminUid = admin.uid,
                adminName = admin.name,
                oldStatus = oldStatus,
                oldSeverity = oldSeverity
            )) {
                is Result.Success -> {
                    // Log response_updated separately if only response changed
                    if (newStatus == oldStatus && newSeverity == oldSeverity && adminResponse != null) {
                        try {
                            adminRepository.logActivity(
                                actorId = admin.uid,
                                actorName = admin.name,
                                actorRole = "administrator",
                                action = "report.response_updated",
                                entityType = "incidentReport",
                                entityId = reportId,
                                description = "Admin response updated"
                            )
                        } catch (_: Exception) { }
                    }
                    _updateState.value = UiState.Success(Unit)
                }
                is Result.Error -> _updateState.value = UiState.Error(result.message ?: "Failed to update")
                is Result.Loading -> {}
            }
        }
    }

    fun loadCategories() {
        viewModelScope.launch {
            categoryRepository.observeAllCategories()
                .catch { _categories.value = UiState.Error(it.message ?: "Failed") }
                .collect { _categories.value = UiState.Success(it) }
        }
    }

    fun createCategory(
        name: String,
        description: String?,
        mitigationTips: List<String> = emptyList(),
        recommendedEvidence: List<String> = emptyList()
    ) {
        val admin = currentAdmin ?: return
        val slug = name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
        viewModelScope.launch {
            _updateState.value = UiState.Loading
            when (val result = categoryRepository.createCategory(name, slug, description, mitigationTips, recommendedEvidence, admin.uid)) {
                is Result.Success -> {
                    try {
                        adminRepository.logActivity(
                            actorId = admin.uid,
                            actorName = admin.name,
                            actorRole = "administrator",
                            action = "category.created",
                            entityType = "category",
                            entityId = result.data,
                            description = "Category created: $name"
                        )
                    } catch (_: Exception) { }
                    _updateState.value = UiState.Success(Unit)
                }
                is Result.Error -> _updateState.value = UiState.Error(result.message ?: "Failed")
                is Result.Loading -> {}
            }
        }
    }

    fun updateCategory(
        categoryId: String,
        name: String,
        description: String?,
        mitigationTips: List<String> = emptyList(),
        recommendedEvidence: List<String> = emptyList()
    ) {
        val slug = name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
        viewModelScope.launch {
            _updateState.value = UiState.Loading
            when (val result = categoryRepository.updateCategory(categoryId, name, slug, description, mitigationTips, recommendedEvidence)) {
                is Result.Success -> {
                    try {
                        val admin = currentAdmin
                        if (admin != null) {
                            adminRepository.logActivity(
                                actorId = admin.uid,
                                actorName = admin.name,
                                actorRole = "administrator",
                                action = "category.updated",
                                entityType = "category",
                                entityId = categoryId,
                                description = "Category updated: $name"
                            )
                        }
                    } catch (_: Exception) { }
                    _updateState.value = UiState.Success(Unit)
                }
                is Result.Error -> _updateState.value = UiState.Error(result.message ?: "Failed")
                is Result.Loading -> {}
            }
        }
    }

    fun toggleCategory(categoryId: String, isActive: Boolean) {
        viewModelScope.launch {
            _updateState.value = UiState.Loading
            when (val result = categoryRepository.toggleCategoryActive(categoryId, isActive)) {
                is Result.Success -> {
                    try {
                        val admin = currentAdmin
                        if (admin != null) {
                            adminRepository.logActivity(
                                actorId = admin.uid,
                                actorName = admin.name,
                                actorRole = "administrator",
                                action = if (isActive) "category.updated" else "category.disabled",
                                entityType = "category",
                                entityId = categoryId,
                                description = "Category ${if (isActive) "enabled" else "disabled"}"
                            )
                        }
                    } catch (_: Exception) { }
                    _updateState.value = UiState.Success(Unit)
                }
                is Result.Error -> _updateState.value = UiState.Error(result.message ?: "Failed")
                is Result.Loading -> {}
            }
        }
    }

    fun deleteCategory(categoryId: String, categoryName: String) {
        viewModelScope.launch {
            _updateState.value = UiState.Loading
            when (val result = categoryRepository.deleteCategory(categoryId)) {
                is Result.Success -> {
                    try {
                        val admin = currentAdmin
                        if (admin != null) {
                            adminRepository.logActivity(
                                actorId = admin.uid,
                                actorName = admin.name,
                                actorRole = "administrator",
                                action = "category.deleted",
                                entityType = "category",
                                entityId = categoryId,
                                description = "Kategori dihapus: $categoryName"
                            )
                        }
                    } catch (_: Exception) { }
                    _updateState.value = UiState.Success(Unit)
                }
                is Result.Error -> _updateState.value = UiState.Error(result.message ?: "Gagal menghapus kategori")
                is Result.Loading -> {}
            }
        }
    }

    fun deleteReport(reportId: String, reportTitle: String) {
        viewModelScope.launch {
            _updateState.value = UiState.Loading
            when (val result = reportRepository.deleteReport(reportId)) {
                is Result.Success -> {
                    try {
                        val admin = currentAdmin
                        if (admin != null) {
                            adminRepository.logActivity(
                                actorId = admin.uid,
                                actorName = admin.name,
                                actorRole = "administrator",
                                action = "report.deleted",
                                entityType = "incidentReport",
                                entityId = reportId,
                                description = "Laporan dihapus: $reportTitle"
                            )
                        }
                    } catch (_: Exception) { }
                    _updateState.value = UiState.Success(Unit)
                }
                is Result.Error -> _updateState.value = UiState.Error(result.message ?: "Gagal menghapus laporan")
                is Result.Loading -> {}
            }
        }
    }

    fun loadActivityLogs() {
        viewModelScope.launch {
            adminRepository.observeActivityLogs()
                .catch { _activityLogs.value = UiState.Error(it.message ?: "Gagal memuat log aktivitas") }
                .collect { _activityLogs.value = UiState.Success(it) }
        }
    }

    fun resetUpdateState() {
        _updateState.value = UiState.Idle
    }
}

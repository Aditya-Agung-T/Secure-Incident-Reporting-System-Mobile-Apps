package com.adit.sirs.data.mapper

import com.adit.sirs.data.model.UserDto
import com.adit.sirs.domain.model.User
import com.adit.sirs.domain.model.UserRole

object UserMapper {
    fun toDomain(dto: UserDto): User {
        return User(
            uid = dto.uid,
            name = dto.name,
            email = dto.email,
            role = UserRole.fromString(dto.role),
            isActive = dto.isActive,
            photoUrl = dto.photoUrl,
            createdAt = dto.createdAt,
            updatedAt = dto.updatedAt,
            lastLoginAt = dto.lastLoginAt
        )
    }

    fun toDto(user: User): UserDto {
        return UserDto(
            uid = user.uid,
            name = user.name,
            email = user.email,
            role = user.role.value,
            isActive = user.isActive,
            photoUrl = user.photoUrl,
            createdAt = user.createdAt,
            updatedAt = user.updatedAt,
            lastLoginAt = user.lastLoginAt
        )
    }
}

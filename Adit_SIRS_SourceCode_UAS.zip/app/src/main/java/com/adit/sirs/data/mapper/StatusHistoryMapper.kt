package com.adit.sirs.data.mapper

import com.adit.sirs.data.model.StatusHistoryDto
import com.adit.sirs.domain.model.StatusHistory

object StatusHistoryMapper {
    fun toDomain(dto: StatusHistoryDto): StatusHistory {
        return StatusHistory(
            id = dto.id,
            fromStatus = dto.fromStatus,
            toStatus = dto.toStatus,
            note = dto.note,
            changedBy = dto.changedBy,
            changedByName = dto.changedByName,
            createdAt = dto.createdAt
        )
    }
}

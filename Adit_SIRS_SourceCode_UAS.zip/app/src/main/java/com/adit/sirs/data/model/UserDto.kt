package com.adit.sirs.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

data class UserDto(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val role: String = "user",
    @get:PropertyName("isActive") @set:PropertyName("isActive") var isActive: Boolean = true,
    val photoUrl: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
    val lastLoginAt: Timestamp? = null
)

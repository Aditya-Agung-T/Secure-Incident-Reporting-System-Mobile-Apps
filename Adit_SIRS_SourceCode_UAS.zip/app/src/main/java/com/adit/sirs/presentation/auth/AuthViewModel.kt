package com.adit.sirs.presentation.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adit.sirs.core.common.UiState
import com.adit.sirs.domain.model.User
import com.adit.sirs.domain.repository.AuthRepository
import com.adit.sirs.core.common.Result
import com.adit.sirs.core.firebase.AnalyticsHelper
import kotlinx.coroutines.tasks.await
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.Timestamp
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val analyticsHelper: AnalyticsHelper
) : ViewModel() {

    private val _loginState = MutableStateFlow<UiState<User>>(UiState.Idle)
    val loginState: StateFlow<UiState<User>> = _loginState.asStateFlow()

    private val _registerState = MutableStateFlow<UiState<User>>(UiState.Idle)
    val registerState: StateFlow<UiState<User>> = _registerState.asStateFlow()

    private val _resetPasswordState = MutableStateFlow<UiState<Unit>>(UiState.Idle)
    val resetPasswordState: StateFlow<UiState<Unit>> = _resetPasswordState.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    init {
        checkCurrentUser()
        seedCategories()
    }

    private fun checkCurrentUser() {
        viewModelScope.launch {
            if (authRepository.isLoggedIn()) {
                when (val result = authRepository.getCurrentUser()) {
                    is Result.Success -> _currentUser.value = result.data
                    else -> _currentUser.value = null
                }
            }
        }
    }

    private fun seedCategories() {
        viewModelScope.launch {
            try {
                val db = FirebaseFirestore.getInstance()
                val snapshot = db.collection("categories").limit(1).get().await()
                if (snapshot.isEmpty) {
                    val now = Timestamp.now()
                    val categories = listOf(
                        "Data Breach" to "data-breach",
                        "Malware/Virus" to "malware-virus",
                        "Phishing" to "phishing",
                        "Unauthorized Access" to "unauthorized-access",
                        "Network Intrusion" to "network-intrusion",
                        "Physical Security" to "physical-security",
                        "Social Engineering" to "social-engineering",
                        "Denial of Service" to "denial-of-service",
                        "Other" to "other"
                    )
                    for ((name, slug) in categories) {
                        db.collection("categories").add(
                            mapOf(
                                "name" to name,
                                "slug" to slug,
                                "description" to null,
                                "isActive" to true,
                                "createdBy" to "system",
                                "createdAt" to now,
                                "updatedAt" to now
                            )
                        ).await()
                    }
                }
            } catch (_: Exception) { }
        }
    }

    fun login(email: String, password: String) {
        viewModelScope.launch {
            _loginState.value = UiState.Loading
            when (val result = authRepository.login(email, password)) {
                is Result.Success -> {
                    _currentUser.value = result.data
                    _loginState.value = UiState.Success(result.data)
                    analyticsHelper.logLoginSuccess(result.data.role.value)
                }
                is Result.Error -> {
                    _loginState.value = UiState.Error(result.message ?: "Login failed")
                }
                is Result.Loading -> { }
            }
        }
    }

    fun register(name: String, email: String, password: String) {
        val passwordValidationError = validatePassword(password)
        if (passwordValidationError != null) {
            _registerState.value = UiState.Error(passwordValidationError)
            return
        }

        viewModelScope.launch {
            _registerState.value = UiState.Loading
            when (val result = authRepository.register(name, email, password)) {
                is Result.Success -> {
                    _currentUser.value = result.data
                    _registerState.value = UiState.Success(result.data)
                    analyticsHelper.logLoginSuccess(result.data.role.value)
                }
                is Result.Error -> {
                    _registerState.value = UiState.Error(result.message ?: "Pendaftaran gagal")
                }
                is Result.Loading -> { }
            }
        }
    }

    private fun validatePassword(password: String): String? {
        return when {
            password.length < 12 -> "Password minimal 12 karakter"
            !password.any { it.isUpperCase() } -> "Password harus memiliki huruf besar"
            !password.any { it.isLowerCase() } -> "Password harus memiliki huruf kecil"
            !password.any { it.isDigit() } -> "Password harus memiliki angka"
            !password.any { !it.isLetterOrDigit() } -> "Password harus memiliki karakter khusus"
            else -> null
        }
    }

    fun sendPasswordReset(email: String) {
        viewModelScope.launch {
            _resetPasswordState.value = UiState.Loading
            when (val result = authRepository.sendPasswordReset(email)) {
                is Result.Success -> {
                    _resetPasswordState.value = UiState.Success(Unit)
                }
                is Result.Error -> {
                    _resetPasswordState.value = UiState.Error(result.message ?: "Failed to send reset email")
                }
                is Result.Loading -> { }
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
            _currentUser.value = null
            _loginState.value = UiState.Idle
            _registerState.value = UiState.Idle
        }
    }

    fun resetLoginState() {
        _loginState.value = UiState.Idle
    }

    fun resetRegisterState() {
        _registerState.value = UiState.Idle
    }

    fun resetPasswordResetState() {
        _resetPasswordState.value = UiState.Idle
    }
}

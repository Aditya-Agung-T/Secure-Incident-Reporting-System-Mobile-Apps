package com.adit.sirs.core.security

import com.adit.sirs.core.constants.AppConstants

object MimeTypeValidator {
    fun isAllowed(mimeType: String?): Boolean {
        return mimeType != null && mimeType in AppConstants.ALLOWED_MIME_TYPES
    }

    fun getExtensionFromMime(mimeType: String): String? {
        return when (mimeType) {
            "image/jpeg", "image/jpg" -> "jpg"
            "image/png" -> "png"
            "application/pdf" -> "pdf"
            else -> null
        }
    }
}

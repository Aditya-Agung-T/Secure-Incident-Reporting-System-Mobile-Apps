package com.adit.sirs.core.util

import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DateFormatter {
    private val displayFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
    private val dateOnlyFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    fun formatTimestamp(timestamp: Timestamp?): String {
        if (timestamp == null) return "-"
        return displayFormat.format(timestamp.toDate())
    }

    fun formatDate(date: Date?): String {
        if (date == null) return "-"
        return dateOnlyFormat.format(date)
    }

    fun formatDateOnly(timestamp: Timestamp?): String {
        if (timestamp == null) return "-"
        return dateOnlyFormat.format(timestamp.toDate())
    }

    fun formatIso(date: Date?): String {
        if (date == null) return ""
        return isoFormat.format(date)
    }
}

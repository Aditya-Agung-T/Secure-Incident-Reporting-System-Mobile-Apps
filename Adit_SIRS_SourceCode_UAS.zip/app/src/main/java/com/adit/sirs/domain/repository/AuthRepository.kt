package com.adit.sirs.domain.repository

import com.adit.sirs.domain.model.User
import com.adit.sirs.core.common.Result

interface AuthRepository {
    suspend fun login(email: String, password: String): Result<User>
    suspend fun register(name: String, email: String, password: String): Result<User>
    suspend fun logout(): Result<Unit>
    suspend fun sendPasswordReset(email: String): Result<Unit>
    suspend fun getCurrentUser(): Result<User?>
    fun isLoggedIn(): Boolean
}

package com.adit.sirs.data.remote

import com.adit.sirs.core.constants.AppConstants
import com.adit.sirs.data.model.UserDto
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirestoreUserDataSource @Inject constructor(
    private val firestore: FirebaseFirestore
) {
    private val usersCollection get() = firestore.collection(AppConstants.COLLECTION_USERS)

    suspend fun createUserProfile(uid: String, name: String, email: String) {
        val userData = mapOf(
            "uid" to uid,
            "name" to name,
            "email" to email,
            "role" to "user",
            "isActive" to true,
            "createdAt" to Timestamp.now(),
            "updatedAt" to Timestamp.now()
        )
        usersCollection.document(uid).set(userData).await()
    }

    suspend fun getUserProfile(uid: String): UserDto? {
        val doc = usersCollection.document(uid).get().await()
        if (doc.exists()) {
            val dto = doc.toObject(UserDto::class.java)
            return dto?.copy(uid = doc.id)
        }
        return null
    }

    suspend fun updateLastLogin(uid: String) {
        usersCollection.document(uid).update(
            mapOf(
                "lastLoginAt" to Timestamp.now(),
                "updatedAt" to Timestamp.now()
            )
        ).await()
    }

    suspend fun updateProfile(uid: String, name: String) {
        usersCollection.document(uid).update(
            mapOf(
                "name" to name,
                "updatedAt" to Timestamp.now()
            )
        ).await()
    }
}

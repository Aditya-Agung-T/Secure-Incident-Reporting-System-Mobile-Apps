package com.adit.sirs.domain.repository

import com.adit.sirs.core.common.Result
import com.adit.sirs.domain.model.ActivityLog
import com.adit.sirs.domain.model.IncidentReport
import kotlinx.coroutines.flow.Flow

interface AdminRepository {
    fun observeAllReports(status: String? = null): Flow<List<IncidentReport>>
    suspend fun updateReportStatus(
        reportId: String,
        newStatus: String,
        newSeverity: String,
        adminResponse: String?,
        adminUid: String,
        adminName: String,
        oldStatus: String,
        oldSeverity: String
    ): Result<Unit>
    fun observeActivityLogs(): Flow<List<ActivityLog>>
    suspend fun logActivity(
        actorId: String?,
        actorName: String?,
        actorRole: String?,
        action: String,
        entityType: String?,
        entityId: String?,
        description: String,
        context: Map<String, Any>? = null
    ): Result<Unit>
}

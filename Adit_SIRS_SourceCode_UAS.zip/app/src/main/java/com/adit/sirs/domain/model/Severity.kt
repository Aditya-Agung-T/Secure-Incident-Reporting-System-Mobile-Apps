package com.adit.sirs.domain.model

enum class Severity(val value: String, val displayName: String) {
    LOW("low", "Low"),
    MEDIUM("medium", "Medium"),
    HIGH("high", "High"),
    CRITICAL("critical", "Critical");

    companion object {
        fun fromString(value: String): Severity {
            return entries.firstOrNull { it.value == value } ?: LOW
        }
    }
}

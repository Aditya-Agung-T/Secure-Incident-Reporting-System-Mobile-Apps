# Fitur Keamanan Aplikasi

Dokumen ini merangkum fitur keamanan yang diterapkan pada aplikasi SIRS.

## 1. Autentikasi Pengguna

Aplikasi menggunakan Firebase Authentication untuk proses login, registrasi, reset password, dan pengelolaan session pengguna.

Password pengguna tidak disimpan di Firestore. Password dikelola oleh Firebase Authentication dan disimpan secara aman oleh layanan Firebase. Firestore hanya menyimpan data profil seperti UID, nama, email, role, dan status akun.

## 2. Session Management

Session pengguna dikelola oleh Firebase Authentication. Setelah login, Firebase menyediakan ID Token berbentuk JWT dan refresh token yang dikelola otomatis oleh Firebase SDK.

- ID Token memiliki masa berlaku terbatas.
- Refresh token digunakan oleh Firebase SDK untuk memperbarui session.
- Logout dilakukan melalui Firebase Authentication sehingga session lokal pengguna dihapus.

Aplikasi tidak membuat JWT manual di sisi Android karena secret key tidak aman jika disimpan di dalam APK.

## 3. Validasi Password

Form registrasi menampilkan aturan password agar pengguna mengetahui standar keamanan yang harus dipenuhi.

Aturan password:

- Minimal 12 karakter.
- Memiliki huruf besar.
- Memiliki huruf kecil.
- Memiliki angka.
- Memiliki karakter khusus atau simbol.

## 4. Hak Akses Pengguna dan Admin

Aplikasi membedakan hak akses pengguna biasa dan admin.

- Pengguna hanya dapat melihat dan mengelola laporan miliknya sendiri.
- Admin dapat melihat dan menangani seluruh laporan.
- Pembuatan akun admin tidak tersedia dari halaman registrasi publik.

## 5. Validasi Input

Input pada form laporan divalidasi sebelum data disimpan. Validasi dilakukan untuk memastikan field penting seperti judul, kategori, tingkat keparahan, deskripsi, lokasi, dan tanggal kejadian terisi dengan benar.

Validasi panjang input juga diterapkan pada judul, deskripsi, dan lokasi laporan. Di sisi Firestore, aturan keamanan turut membatasi ukuran field laporan agar data yang masuk tetap sesuai format aplikasi.

## 6. Validasi Upload File

Bukti pendukung laporan dibatasi hanya untuk format yang diperbolehkan.

Format yang didukung:

- JPG/JPEG
- PNG
- PDF

Validasi file meliputi:

- MIME type.
- Ekstensi file.
- Ukuran file.
- Signature file / magic bytes.

Validasi ini bertujuan agar file yang diupload benar-benar sesuai dengan format yang diizinkan, bukan hanya berdasarkan nama file.

## 7. Rate Limiting

Aplikasi menerapkan pembatasan aksi tertentu untuk mengurangi risiko penyalahgunaan, seperti pembuatan laporan dan upload file secara berlebihan dalam waktu singkat.

Jika batas tercapai, pengguna akan diminta menunggu sebelum melakukan aksi berikutnya.

## 8. Activity Log

Aktivitas penting pada aplikasi dicatat agar perubahan data dapat ditelusuri. Contoh aktivitas yang dicatat:

- Registrasi pengguna.
- Pembuatan laporan.
- Perubahan laporan.
- Perubahan status laporan.
- Perubahan kategori.
- Upload bukti laporan.

## 9. Firestore Security Rules

Project menyertakan file `firestore.rules` untuk mengatur akses data di Cloud Firestore. Rules digunakan untuk membatasi akses berdasarkan status login, role pengguna, status aktif akun, dan kepemilikan data.

## 10. Keamanan Data Upload

Upload bukti laporan menggunakan Cloudinary. Aplikasi hanya menyimpan metadata file yang diperlukan, seperti URL file, nama file, ukuran, format, dan waktu upload.

Secret untuk operasi sensitif tidak disimpan langsung di source code Android.
